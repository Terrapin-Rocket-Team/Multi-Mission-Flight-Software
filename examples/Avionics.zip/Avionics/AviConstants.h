#ifndef AVI_CONSTANTS_H
#define AVI_CONSTANTS_H

inline int GPS_LED = 32;

#endif